module.exports = () => {
  return Promise.resolve([1, 2, 3])
}
